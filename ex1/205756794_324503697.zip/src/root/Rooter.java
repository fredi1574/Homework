package root;

public class Rooter {

	private double setPrecision;

	public Rooter(double precision) {
	}

	public void setPrecision(double precision) {
		setPrecision = precision;
	}

	public double sqrt(double x) {
		double one = x / 2;

		do {
			double two = x / one;
			double abs = Math.abs(one - two);

			if (one == two || abs <= setPrecision)
				return one;

			one = (one + two) / 2;
		} while (one != 0);
	}
}
