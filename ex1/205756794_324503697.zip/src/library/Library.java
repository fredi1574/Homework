package library;

public class Library {

	private Book[] library;

	public Library(int size) {
		this.library = new Book[size];
	}

	public void setBook(int bookNum, String title, Author auth) {
		Book book = new Book(title, auth);
		library[bookNum] = book;
	}

	public Book getBook(int bookNum) {
		return library[bookNum];
	}

}
